<!-- Sticky Footer -->
<footer class="sticky-footer">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>Copyright © <a href="https://www.sarjanakomedi.com"><?php echo SITE_NAME ."</a> ". Date('Y') ?></span>
    </div>
  </div>
</footer>